// import logo from './logo.svg';
import './App.css';
import ToDo from './Components/ToDo'

function App() {
  return (
    <div className="App">
      <div className="container">
        <h1>ToDo List</h1>

        <div className="addSection">
          <input type="text" placeholder="Enter your task" />
          <button>Add</button>
        </div>

        <div className="toDoLists">
          <ToDo text="Hii" />
          
          <ToDo text="Hello"/>
          
          <ToDo text="Bye" />
        </div>

      </div>
    </div>
  );
}

export default App;
